export default {
  authors: [],
  courses: [],
  groups: [],
	questions: [],
	companies: [],
  ajaxCallsInProgress: 0,
	auth: {
		currently: 'ANONYMOUS',
		username: null,
		uid: null
	}

};
